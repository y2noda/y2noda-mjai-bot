from abc import ABC, abstractmethod

# MahjongAIBotクラスの型ヒントのためにインポート (循環参照を避けるためTYPE_CHECKINGを使用)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..bot import MahjongAIBot


class BaseStrategy(ABC):
    """思考戦略の基底クラス (インターフェース)"""

    @abstractmethod
    def decide_action(self, bot: "MahjongAIBot") -> str:
        """与えられたボットの状態に基づいて、取るべきアクションを決定します。

        Args:
            bot (MahjongAIBot): 現在のボットの状態を持つインスタンス。

        Returns:
            str: Mjai形式のアクション文字列。

        """
        raise NotImplementedError
