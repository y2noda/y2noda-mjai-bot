import sys

from loguru import logger
from mjai import Bot

# Import the ThinkingEngine (relative import)
from engine.thinking_engine import ThinkingEngine

logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> <level>{level} {message}</level>",
    level="DEBUG",
)


class MahjongAIBot(Bot):
    """Main bot class. Delegates thinking logic to ThinkingEngine."""

    def __init__(self, player_id: int):
        super().__init__(player_id)
        # Instantiate the thinking engine
        # The engine itself will choose the strategy internally for now
        self.engine = ThinkingEngine()
        logger.info("MahjongAIBot が初期化されました。")

    def think(self) -> str:
        logger.debug(f"--- MahjongAIBot.think をプレイヤー {self.player_id} で開始 ---")
        # Delegate the decision making to the engine
        # The engine will need access to the bot's state (self)
        try:
            logger.debug("engine.decide_action を呼び出しています...")
            action_str = self.engine.decide_action(self)
            logger.info(f"プレイヤー {self.player_id} がアクションを選択: {action_str}")
            logger.debug(
                f"--- MahjongAIBot.think 終了、アクションを返します: {action_str} ---"
            )
            return action_str
        except Exception as e:
            logger.error(
                f"bot.think での思考プロセス中にエラーが発生しました: {e}",
                exc_info=True,
            )
            # Fallback action in case of error
            logger.warning("エラーのためフォールバックアクションを実行します。")
            # Consider just discarding the last drawn tile if possible
            if self.can_discard and self.last_self_tsumo:
                action = self.action_discard(self.last_self_tsumo)
                logger.warning(
                    f"フォールバック: 最後のツモ牌 {self.last_self_tsumo} を捨てます ({action})"
                )
                return action
            # tehai_mjai が空でないことを確認する
            if self.can_discard and self.tehai_mjai:
                discard_tile = self.tehai_mjai[0]
                action = self.action_discard(discard_tile)
                logger.warning(
                    f"フォールバック: 手牌の最初の牌 {discard_tile} を捨てます ({action})"
                )
                return action

            # If no other action is possible, do nothing (should be rare)
            logger.warning("フォールバック: 打牌可能な牌がありません。何もしません。")
            return self.action_nothing()


if __name__ == "__main__":
    MahjongAIBot(player_id=int(sys.argv[1])).start()
