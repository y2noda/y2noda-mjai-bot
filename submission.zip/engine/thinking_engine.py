from typing import TYPE_CHECKING

from loguru import logger

from strategies.base_strategy import BaseStrategy
from strategies.rule_based.rule_based_strategy import RuleBasedStrategy

if TYPE_CHECKING:
    from bot import MahjongAIBot

# logger.remove()
# logger.add(
#     sys.stderr,
#     format="<green>{time:HH:mm:ss}</green> <level>{level} {message}</level>",
#     level="DEBUG",
# )


class ThinkingEngine:
    """Delegates thinking logic to a selected strategy."""

    def __init__(self):
        # For now, we directly instantiate RuleBasedStrategy
        self.strategy: BaseStrategy = RuleBasedStrategy()
        logger.info(f"使用中の戦略: {self.strategy.__class__.__name__}")

    def decide_action(self, bot: "MahjongAIBot") -> str:
        """Decides the next action using the selected strategy.

        Args:
            bot (MahjongAIBot): The current state of the bot.

        Returns:
            str: The action string decided by the strategy.

        """
        logger.debug(f"--- ThinkingEngine.decide_action をプレイヤー {bot.player_id} で開始 ---")
        logger.debug(f"使用中の戦略: {self.strategy.__class__.__name__}")
        try:
            # Delegate the decision making to the selected strategy
            logger.debug("strategy.decide_action を呼び出しています...")
            action_str = self.strategy.decide_action(bot)
            logger.debug(f"戦略がアクションを返しました: {action_str}")
            logger.debug(f"--- エンジンがアクションを決定しました: {action_str} ---")
            return action_str
        except Exception as e:
            logger.error(f"戦略の実行中にエラーが発生しました: {e}", exc_info=True)
            # Fallback or re-raise depending on desired behavior
            raise
